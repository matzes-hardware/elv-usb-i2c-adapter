﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Globalization;
using System.Windows.Forms.DataVisualization.Charting;

namespace Eq3.misc.USBI2C.I2C_OPT3001
{
    public class OPT3001 : AbstractDevice
    {
        public OPT3001(UsbI2C usbI2C)
            : base(usbI2C)
        {
            this.GetDeviceID();
            this.GetManuID();
        }

        private bool chartRunning = false;
        private System.Threading.Thread startChart;
        private String deviceID = "";
        private String manuID = "";
        private const String DEFAULT_SLAVE = "88";
        private const double MAX_LUX = 83865.6;
        private const double MIN_LUX = 0;
        private const int MAX_MANTISSA = 4095;
        private const int MIN_MANTISSA = 0;
        private const int MAX_EXPONENT = 15;
        private const int MIN_EXPONENT = 0;
        private String lowLimitMantissa = MIN_MANTISSA.ToString();
        private String lowLimitExponent = MIN_EXPONENT.ToString();
        private String highLimitMantissa = MIN_MANTISSA.ToString("X2");
        private String highLimitExponent = MIN_EXPONENT.ToString("X1");


        public OPT3001.UiElements uiElements;

        public struct UiElements
        {
            /// <summary>
            /// Gets or sets output-command list.
            /// </summary>
            /// <value>Output-command list.</value>
            public ListBox ListBoxOutput { get; set; }

            /// <summary>
            /// Gets or sets input-command list.
            /// </summary>
            /// <value>Input-command list.</value>
            public ListBox ListBoxInput { get; set; }
            public ComboBox ComboBoxReg1LuxFullScale { get; set; }
            public ComboBox ComboBoxReg1Mode { get; set; }
            public ComboBox ComboBoxReg1FaultCount { get; set; }
            public ComboBox ComboBoxReg1Latch { get; set; }
            public ComboBox ComboBoxReg1Ms { get; set; }
            public ComboBox ComboBoxReg1ExponentMask { get; set; }
            public ComboBox ComboBoxReg1AlertPolarity { get; set; }
            public ComboBox ComboBoxSlave { get; set; }
            public TextBox TextBoxLux { get; set; }
            public TextBox TextBoxReg0E { get; set; }
            public TextBox TextBoxReg0R { get; set; }
            public TextBox TextBoxLowLimitExponent { get; set; }
            public TextBox TextBoxHighLimitExponent { get; set; }
            public TextBox TextBoxLowLimitMantissa { get; set; }
            public TextBox TextBoxHighLimitMantissa { get; set; }
            public TextBox TextBoxLowLimitLux { get; set; }
            public TextBox TextBoxHighLimitLux { get; set; }
            public TextBox TextBoxAbfrageIntervallMs { get; set; }
            public Label LabelDeviceID { get; set; }
            public Label LabelManufactureID { get; set; }
            public CheckBox OVF { get; set; }
            public CheckBox CRF { get; set; }
            public CheckBox FH { get; set; }
            public CheckBox FL { get; set; }
            public Chart ChartLux { get; set; }
        }

        public bool getChartRunning()
        {
            return this.chartRunning;
        }

        public void ImportUiElements(UiElements uiElements)
        {
            this.uiElements = uiElements;
            this.uiElements.ComboBoxReg1AlertPolarity.SelectedIndex = 0;
            this.uiElements.ComboBoxReg1ExponentMask.SelectedIndex = 0;
            this.uiElements.ComboBoxReg1FaultCount.SelectedIndex = 0;
            this.uiElements.ComboBoxReg1Latch.SelectedIndex = 0;
            this.uiElements.ComboBoxReg1LuxFullScale.SelectedIndex = 0;
            this.uiElements.ComboBoxReg1Mode.SelectedIndex = 0;
            this.uiElements.ComboBoxReg1Ms.SelectedIndex = 0;
            this.uiElements.ComboBoxSlave.SelectedIndex = 0;
            this.uiElements.TextBoxLowLimitExponent.Text = "0";
            this.uiElements.TextBoxLowLimitMantissa.Text = "0";
            this.uiElements.TextBoxHighLimitExponent.Text = "B";
            this.uiElements.TextBoxHighLimitMantissa.Text = "FFF";
            this.uiElements.TextBoxLowLimitLux.Text = "0";
            this.uiElements.TextBoxHighLimitLux.Text = MAX_LUX.ToString();
            this.uiElements.LabelDeviceID.Text = deviceID;
            this.uiElements.LabelManufactureID.Text = manuID;
            this.uiElements.TextBoxAbfrageIntervallMs.Text = "100";
        }

        public enum ExponentMask
        {
            Unmasked = 0,
            Masked = 1,
        }

        public enum ConversionTime
        {
            CT100ms = 0,
            CT800ms = 1,
        }

        public enum Mode
        {
            ShutDown = 0,
            SingleShot = 1,
            Continuous2= 2,
            Continuous3 = 3,
        }

        public enum Slave
        {
            Slave0x88_0x89 = 0,
            Slave0x8A_0x8B = 1,
            Slave0x8C_0x8D = 2,
            Slave0x8E_0x8F = 3,

        }

        public enum FaultCount
        {
            FC1 = 0,
            FC2 = 1,
            FC3 = 2,
            FC4 = 3,
        }

        public enum AlertPolarity
        {
            ActiveLow = 0,
            ActiveHigh = 1,
        }

        public enum LatchControl
        {
            TransparentMode = 0,
            ComparaterMode = 1,
        }

        public enum Range
        {
            Range_40_96 = 0,
            Range_81_92 = 1,
            Range_163_84 = 2,
            Range_327_68 = 3,
            Range_655_36 = 4,
            Range_1310_72 = 5, 
            Range_2621_44 = 6,
            Range_5242_88 = 7,
            Range_10485_76 = 8,
            Range_20971_52 = 9,
            Range_41943_04 = 10,
            Range_83886_08 = 11,
            Range_Auto0xC = 12,
            Range_Auto0xD = 13,
            Range_Auto0xE = 14,
            Range_Auto0xF = 15,
        }

        

        public void readRegx00()
        {
            String slave = this.GetSlave();

            string command = "S" + slave + " 00 R02 P";
            string result = this.UsbI2C.SendReceiveCommand(command);

            if (result == string.Empty)
            {
                //this.ShowError(20);
            }
            else
            {
                this.uiElements.ListBoxInput.Items.Add(result);
                this.uiElements.ListBoxInput.TopIndex = this.uiElements.ListBoxInput.Items.Count - 1;

                if (result.StartsWith("Err") || result.StartsWith("R"))
                {
                    //this.ShowError(10);
                    return;
                }

                try
                {
                    // Status auswerten
                    result = result.Replace(" ", string.Empty);
                    byte[] resultBytes = new byte[result.Length / 2];
                    for (int i = 0; i < result.Length; i += 2)
                    {
                        resultBytes[i / 2] = Convert.ToByte(result.Substring(i, 2), 16);
                    }
                    //Bytes in die richtige reihenfolge bringen
                    byte[] tempResultBytes = new byte[resultBytes.Length];
                    tempResultBytes[0] = resultBytes[1];
                    tempResultBytes[1] = resultBytes[0];

                    resultBytes = tempResultBytes;

                    //TODO Anzeige der Werte
                    int e30 = ((resultBytes[1] >> 4) & 0x0F);
                    Console.WriteLine(e30);

                    this.uiElements.TextBoxReg0E.Text = e30.ToString();

                    int r110 = BitConverter.ToInt16(resultBytes, 0) & 0x0FFF;

                    this.uiElements.TextBoxReg0R.Text = r110.ToString();

                    double lux = this.GetLux(e30, r110);

                    this.uiElements.TextBoxLux.Text = lux.ToString();
                }
                catch
                {

                }
            }
        }

        public double GetLux(int exponent, int mantisse)
        {
            return 0.01 * Math.Pow(2, exponent) * mantisse;
        }

        public string GetSlave()
        {
            switch (this.uiElements.ComboBoxSlave.SelectedIndex)
            {
                case (int)Slave.Slave0x88_0x89:
                    return "88";
                case (int)Slave.Slave0x8A_0x8B:
                    return "8A";
                case (int)Slave.Slave0x8C_0x8D:
                    return "8C";
                case (int)Slave.Slave0x8E_0x8F:
                    return "8E";
                default:
                    return String.Empty;
            }
        }

        internal void readRegx01()
        {
            String slave = this.GetSlave();
            string command = "S";
            command += slave;
            command += "01 R02 P";
            //RegisterResult
            string result = this.UsbI2C.SendReceiveCommand(command);


            if (result != string.Empty)
            {
                this.uiElements.ListBoxInput.Items.Add(result);
                this.uiElements.ListBoxInput.TopIndex = this.uiElements.ListBoxInput.Items.Count - 1;

                if (result.StartsWith("Err") || result.StartsWith("R"))
                {
                   //this.ShowError(10);
                    return;
                }

                try
                {
                    // Status auswerten
                    result = result.Replace(" ", string.Empty);
                    byte[] resultBytes = new byte[result.Length / 2];
                    for (int i = 0; i < result.Length; i += 2)
                    {
                        resultBytes[i / 2] = Convert.ToByte(result.Substring(i, 2), 16);
                    }

                    // Anzeige der Werte
                    int faultCount = ((resultBytes[1]) & 0x03);
                    int mask = ((resultBytes[1] >> 2) & 0x01);
                    int polarity = ((resultBytes[1] >> 3) & 0x01);
                    int control = ((resultBytes[1] >> 4) & 0x01);
                    int flagLow = ((resultBytes[1] >> 5) & 0x01);
                    int flagHigh = ((resultBytes[1] >> 6) & 0x01);
                    int conversion = ((resultBytes[1] >> 7) & 0x01);

                    int overflowFlag = ((resultBytes[0]) & 0x01);
                    int mode = ((resultBytes[0] >> 1) & 0x03);
                    int time = ((resultBytes[0] >> 3) & 0x01);
                    int range = ((resultBytes[0] >> 4) & 0xF);

                    this.uiElements.ComboBoxReg1FaultCount.SelectedIndex = this.GetFaultCount(faultCount);
                    this.uiElements.ComboBoxReg1ExponentMask.SelectedIndex = this.GetExponentMask(mask);
                    this.uiElements.ComboBoxReg1AlertPolarity.SelectedIndex = this.GetAlertPolarity(polarity);
                    this.uiElements.ComboBoxReg1Latch.SelectedIndex = this.GetLatchControl(control);
                    this.uiElements.FL.CheckState = this.SetChecked(flagLow);
                    this.uiElements.FH.CheckState = this.SetChecked(flagHigh);
                    this.uiElements.CRF.CheckState = this.SetChecked(conversion);
                    this.uiElements.OVF.CheckState = this.SetChecked(overflowFlag);
                    this.uiElements.ComboBoxReg1Mode.SelectedIndex = this.GetMode(mode);
                    this.uiElements.ComboBoxReg1Ms.SelectedIndex = this.GetConversionTime(time);
                    this.uiElements.ComboBoxReg1LuxFullScale.SelectedIndex = this.GetRange(range);

                }
                catch
                {
                    throw new Exception("Error while setting values for UI");
                }
            }
        }

        internal void WriteRegx01()
        {
            byte[] values = new byte[2];

            //FaultCount
            if (this.uiElements.ComboBoxReg1FaultCount.SelectedIndex.Equals((int)FaultCount.FC2))
            {
                values[1] += BitOperationUtils.Bit0;
            }
            else if(this.uiElements.ComboBoxReg1FaultCount.SelectedIndex.Equals((int)FaultCount.FC3))
            {
                values[1] += BitOperationUtils.Bit1;
            }
            else if (this.uiElements.ComboBoxReg1FaultCount.SelectedIndex.Equals((int)FaultCount.FC4))
            {
                values[1] += BitOperationUtils.Bit0;
                values[1] += BitOperationUtils.Bit1;
            }
           
            //ExponentMask
            if (this.uiElements.ComboBoxReg1ExponentMask.SelectedIndex.Equals((int)ExponentMask.Masked))
            {
                values[1] += BitOperationUtils.Bit2;
            }

            //Polarity
            if (this.uiElements.ComboBoxReg1AlertPolarity.SelectedIndex.Equals((int)AlertPolarity.ActiveHigh))
            {
                values[1] += BitOperationUtils.Bit3;
            }

            //Latch
            if (this.uiElements.ComboBoxReg1Latch.SelectedIndex.Equals((int)LatchControl.ComparaterMode))
            {
                values[1] += BitOperationUtils.Bit4;
            }

            //Flag low
            if (this.uiElements.FL.CheckState.Equals(true))
            {
                values[1] += BitOperationUtils.Bit5;
            }

            //Flag high
            if (this.uiElements.FH.CheckState.Equals(true))
            {
                values[1] += BitOperationUtils.Bit6;
            }

            //Flag low
            if (this.uiElements.CRF.CheckState.Equals(true))
            {
                values[1] += BitOperationUtils.Bit7;
            }

            //Flag low
            if (this.uiElements.OVF.CheckState.Equals(true))
            {
                values[0] += BitOperationUtils.Bit0;
            }

            //Mode
            if (this.uiElements.ComboBoxReg1Mode.SelectedIndex.Equals((int)Mode.SingleShot))
            {
                values[0] += BitOperationUtils.Bit1;
            }
            else if (this.uiElements.ComboBoxReg1Mode.SelectedIndex.Equals((int)Mode.Continuous2))
            {
                values[0] += BitOperationUtils.Bit2;
            }
            else if (this.uiElements.ComboBoxReg1Mode.SelectedIndex.Equals((int)Mode.Continuous3))
            {
                values[0] += BitOperationUtils.Bit1;
                values[0] += BitOperationUtils.Bit2;
            }

            //Conversion Time
            if (this.uiElements.ComboBoxReg1Ms.SelectedIndex.Equals((int)ConversionTime.CT800ms))
            {
                values[0] += BitOperationUtils.Bit3;
            }

            //Range
            if (this.uiElements.ComboBoxReg1LuxFullScale.SelectedIndex.Equals((int)Range.Range_81_92))
            {
                values[0] += BitOperationUtils.Bit4;
            }
            else if (this.uiElements.ComboBoxReg1LuxFullScale.SelectedIndex.Equals((int)Range.Range_163_84))
            {
                values[0] += BitOperationUtils.Bit5;
            }
            else if (this.uiElements.ComboBoxReg1LuxFullScale.SelectedIndex.Equals((int)Range.Range_327_68))
            {
                values[0] += BitOperationUtils.Bit4;
                values[0] += BitOperationUtils.Bit5;
            }
            else if (this.uiElements.ComboBoxReg1LuxFullScale.SelectedIndex.Equals((int)Range.Range_655_36))
            {
                values[0] += BitOperationUtils.Bit6;
            }
            else if (this.uiElements.ComboBoxReg1LuxFullScale.SelectedIndex.Equals((int)Range.Range_1310_72))
            {
                values[0] += BitOperationUtils.Bit4;
                values[0] += BitOperationUtils.Bit6;
            }
            else if (this.uiElements.ComboBoxReg1LuxFullScale.SelectedIndex.Equals((int)Range.Range_2621_44))
            {
                values[0] += BitOperationUtils.Bit5;
                values[0] += BitOperationUtils.Bit6;
            }
            else if (this.uiElements.ComboBoxReg1LuxFullScale.SelectedIndex.Equals((int)Range.Range_5242_88))
            {
                values[0] += BitOperationUtils.Bit4;
                values[0] += BitOperationUtils.Bit5;
                values[0] += BitOperationUtils.Bit6;
            }
            else if (this.uiElements.ComboBoxReg1LuxFullScale.SelectedIndex.Equals((int)Range.Range_10485_76))
            {
                values[0] += BitOperationUtils.Bit7;
            }
            else if (this.uiElements.ComboBoxReg1LuxFullScale.SelectedIndex.Equals((int)Range.Range_20971_52))
            {
                values[0] += BitOperationUtils.Bit4;
                values[0] += BitOperationUtils.Bit7;
            }
            else if (this.uiElements.ComboBoxReg1LuxFullScale.SelectedIndex.Equals((int)Range.Range_41943_04))
            {
                values[0] += BitOperationUtils.Bit5;
                values[0] += BitOperationUtils.Bit7;
            }
            else if (this.uiElements.ComboBoxReg1LuxFullScale.SelectedIndex.Equals((int)Range.Range_83886_08))
            {
                values[0] += BitOperationUtils.Bit4;
                values[0] += BitOperationUtils.Bit5;
                values[0] += BitOperationUtils.Bit7;
            }
            else if (this.uiElements.ComboBoxReg1LuxFullScale.SelectedIndex.Equals((int)Range.Range_Auto0xC))
            {
                values[0] += BitOperationUtils.Bit6;
                values[0] += BitOperationUtils.Bit7;
            }
            else if (this.uiElements.ComboBoxReg1LuxFullScale.SelectedIndex.Equals((int)Range.Range_Auto0xD))
            {
                values[0] += BitOperationUtils.Bit4;
                values[0] += BitOperationUtils.Bit6;
                values[0] += BitOperationUtils.Bit7;
            }
            else if (this.uiElements.ComboBoxReg1LuxFullScale.SelectedIndex.Equals((int)Range.Range_Auto0xE))
            {
                values[0] += BitOperationUtils.Bit5;
                values[0] += BitOperationUtils.Bit6;
                values[0] += BitOperationUtils.Bit7;
            }
            else if (this.uiElements.ComboBoxReg1LuxFullScale.SelectedIndex.Equals((int)Range.Range_Auto0xF))
            {
                values[0] += BitOperationUtils.Bit4;
                values[0] += BitOperationUtils.Bit5;
                values[0] += BitOperationUtils.Bit6;
                values[0] += BitOperationUtils.Bit7;
            }

            string slave = this.GetSlave();
            string command = "S" + slave + " 01 ";
            command += BitConverter.ToString(values).Replace("-", " ");
            command += " P";
            this.uiElements.ListBoxOutput.Items.Add(command);
            this.uiElements.ListBoxOutput.TopIndex = this.uiElements.ListBoxOutput.Items.Count - 1;
            string result = this.UsbI2C.SendReceiveCommand(command);
        }

        internal void WriteRegx02x03()
        {
            //reg02
            string slave = this.GetSlave();
            string command = "S" + slave + " 02 ";
            int mantissa = Int32.Parse(this.uiElements.TextBoxLowLimitMantissa.Text, NumberStyles.AllowHexSpecifier);
            int exponent = Int32.Parse(this.uiElements.TextBoxLowLimitExponent.Text, NumberStyles.AllowHexSpecifier) ;
            byte[] values = new byte[2] { (byte)(mantissa >> 8), (byte)mantissa };
            values[0] = (byte)(values[0] | exponent << 4);
            command += BitConverter.ToString(values).Replace("-", " ");
            command += " P";

            this.uiElements.ListBoxOutput.Items.Add(command);
            this.uiElements.ListBoxOutput.TopIndex = this.uiElements.ListBoxOutput.Items.Count - 1;

            string result = this.UsbI2C.SendReceiveCommand(command);
            this.uiElements.TextBoxLowLimitLux.Text = this.GetLux(exponent, mantissa).ToString();

            //reg03
            command = "S" + slave + " 03 ";
            mantissa = Int32.Parse(this.uiElements.TextBoxHighLimitMantissa.Text, NumberStyles.AllowHexSpecifier);
            exponent = Int32.Parse(this.uiElements.TextBoxHighLimitExponent.Text, NumberStyles.AllowHexSpecifier);
            values = new byte[2] { (byte)(mantissa >> 8), (byte)mantissa };
            values[0] = (byte)(values[0] | exponent << 4);
            command += BitConverter.ToString(values).Replace("-", " ");
            command += " P";

            this.uiElements.ListBoxOutput.Items.Add(command);
            this.uiElements.ListBoxOutput.TopIndex = this.uiElements.ListBoxOutput.Items.Count - 1;

            result = this.UsbI2C.SendReceiveCommand(command);
            this.uiElements.TextBoxHighLimitLux.Text = this.GetLux(exponent, mantissa).ToString();

        }

        internal void StartChart(Control parent)
        {
            this.chartRunning = true;
            String slave = this.GetSlave();
            int maxChartLux = 0;
            
            startChart = new System.Threading.Thread(new System.Threading.ThreadStart(() =>
            {
                parent.Invoke(new Action(() => { this.uiElements.ChartLux.Series[0].Points.Dispose(); }));
                parent.Invoke(new Action(() => { this.uiElements.ChartLux.Show(); }));
                for (int intervall = 1; intervall > 0; intervall++)
                {
                    double lux = 0;

                    string command = "S" + slave + " 00 R02 P";
                    string result = this.UsbI2C.SendReceiveCommand(command);

                    if (result == string.Empty)
                    {
                        //this.ShowError(20);
                    }
                    else
                    {
                        if (result.StartsWith("Err") || result.StartsWith("R"))
                        {
                            //this.ShowError(10);
                            return;
                        }

                        try
                        {
                            // Status auswerten
                            result = result.Replace(" ", string.Empty);
                            byte[] resultBytes = new byte[result.Length / 2];
                            for (int i = 0; i < result.Length; i += 2)
                            {
                                resultBytes[i / 2] = Convert.ToByte(result.Substring(i, 2), 16);
                            }

                            //Bytes in die richtige reihenfolge bringen
                            byte[] tempResultBytes = new byte[resultBytes.Length];
                            tempResultBytes[0] = resultBytes[1];
                            tempResultBytes[1] = resultBytes[0];

                            resultBytes = tempResultBytes;

                            //TODO Anzeige der Werte
                            int e30 = ((resultBytes[1] >> 4) & 0x0F);
                            Console.WriteLine(e30);

                            parent.Invoke(new Action(() => { this.uiElements.TextBoxReg0E.Text = e30.ToString(); }));


                            int r110 = BitConverter.ToInt16(resultBytes, 0) & 0x0FFF;

                            parent.Invoke(new Action(() => { this.uiElements.TextBoxReg0R.Text = r110.ToString(); }));

                            lux = this.GetLux(e30, r110);
                            if (lux != 0)
                            {
                                if ((int)lux > maxChartLux)
                                {
                                    maxChartLux = (int)lux;
                                    parent.Invoke(new Action(() => { this.uiElements.ChartLux.ChartAreas[0].AxisY.Maximum = (int)(maxChartLux + (maxChartLux / 10)); }));
                                }
                            }

                            parent.Invoke(new Action(() => { this.uiElements.TextBoxLux.Text = lux.ToString(); }));
                            System.Threading.Thread.Sleep(Int32.Parse(this.uiElements.TextBoxAbfrageIntervallMs.Text));
                        }
                        catch(Exception e)
                        {

                        }
                    }
                    parent.Invoke(new Action(() => { this.uiElements.ChartLux.Series[0].Points.AddXY(intervall, lux); }));
                    //read regx01
                    command = "S";
                    command += slave;
                    command += "01 R02 P";
                    //RegisterResult
                    result = this.UsbI2C.SendReceiveCommand(command);


                    if (result != string.Empty)
                    {

                        if (result.StartsWith("Err") || result.StartsWith("R"))
                        {
                            //this.ShowError(10);
                            return;
                        }

                        try
                        {
                            // Status auswerten
                            result = result.Replace(" ", string.Empty);
                            byte[] resultBytes = new byte[result.Length / 2];
                            for (int i = 0; i < result.Length; i += 2)
                            {
                                resultBytes[i / 2] = Convert.ToByte(result.Substring(i, 2), 16);
                            }

                            // Anzeige der Werte
                            int faultCount = ((resultBytes[1]) & 0x03);
                            int mask = ((resultBytes[1] >> 2) & 0x01);
                            int polarity = ((resultBytes[1] >> 3) & 0x01);
                            int control = ((resultBytes[1] >> 4) & 0x01);
                            int flagLow = ((resultBytes[1] >> 5) & 0x01);
                            int flagHigh = ((resultBytes[1] >> 6) & 0x01);
                            int conversion = ((resultBytes[1] >> 7) & 0x01);

                            int overflowFlag = ((resultBytes[0]) & 0x01);
                            int mode = ((resultBytes[0] >> 1) & 0x03);
                            int time = ((resultBytes[0] >> 3) & 0x01);
                            int range = ((resultBytes[0] >> 4) & 0xF);

                            parent.Invoke(new Action(() => { this.uiElements.ComboBoxReg1FaultCount.SelectedIndex = this.GetFaultCount(faultCount);}));
                            parent.Invoke(new Action(() => { this.uiElements.ComboBoxReg1ExponentMask.SelectedIndex = this.GetExponentMask(mask);}));
                            parent.Invoke(new Action(() => { this.uiElements.ComboBoxReg1AlertPolarity.SelectedIndex = this.GetAlertPolarity(polarity);}));
                            parent.Invoke(new Action(() => { this.uiElements.ComboBoxReg1Latch.SelectedIndex = this.GetLatchControl(control);}));
                            parent.Invoke(new Action(() => { this.uiElements.FL.CheckState = this.SetChecked(flagLow);}));
                            parent.Invoke(new Action(() => { this.uiElements.FH.CheckState = this.SetChecked(flagHigh);}));
                            parent.Invoke(new Action(() => { this.uiElements.CRF.CheckState = this.SetChecked(conversion);}));
                            parent.Invoke(new Action(() => { this.uiElements.OVF.CheckState = this.SetChecked(overflowFlag);}));
                            parent.Invoke(new Action(() => { this.uiElements.ComboBoxReg1Mode.SelectedIndex = this.GetMode(mode);}));
                            parent.Invoke(new Action(() => { this.uiElements.ComboBoxReg1Ms.SelectedIndex = this.GetConversionTime(time);}));
                            parent.Invoke(new Action(() => { this.uiElements.ComboBoxReg1LuxFullScale.SelectedIndex = this.GetRange(range); }));

                        }
                        catch
                        {
                            throw new Exception("Error while setting values for UI");
                        }
                    }
                }
            }));
            this.startChart.Start();
        }

        internal void StopChart()
        {
            if (this.chartRunning == true)
            {
                this.startChart.Abort();
                this.chartRunning = false;
            }
        }

        private int GetRange(int range)
        {
            switch (range)
            {
                case 0:
                    return (int)Range.Range_40_96;
                case 1:
                    return (int)Range.Range_81_92;
                case 2:
                    return (int)Range.Range_163_84;
                case 3:
                    return (int)Range.Range_327_68;
                case 4:
                    return (int)Range.Range_655_36;
                case 5:
                    return (int)Range.Range_1310_72;
                case 6:
                    return (int)Range.Range_2621_44;
                case 7:
                    return (int)Range.Range_5242_88;
                case 8:
                    return (int)Range.Range_10485_76;
                case 9:
                    return (int)Range.Range_20971_52;
                case 10:
                    return (int)Range.Range_41943_04;
                case 11:
                    return (int)Range.Range_83886_08;
                case 12:
                    return (int)Range.Range_Auto0xC;
                case 13:
                    return (int)Range.Range_Auto0xD;
                case 14:
                    return (int)Range.Range_Auto0xE;
                case 15:
                    return (int)Range.Range_Auto0xF;
                default:
                    throw new Exception("Range out of range: " + range);
            }
        }

        private int GetConversionTime(int time)
        {
            switch (time)
            {
                case 0:
                    return (int)ConversionTime.CT100ms;
                case 1:
                    return (int)ConversionTime.CT800ms;
                default:
                    throw new Exception("ConversionTime out of range: " + time);
            }
        }

        private int GetMode(int mode)
        {
            switch (mode)
            {
                case 0:
                    return (int)Mode.ShutDown;
                case 1:
                    return (int)Mode.SingleShot;
                case 2:
                    return (int)Mode.Continuous2;
                case 3:
                    return (int)Mode.Continuous3;
                default:
                    throw new Exception("Mode out of range: " + mode);
            }
        }

        private CheckState SetChecked(int value)
        {
            switch (value)
            {
                case 0:
                    return CheckState.Unchecked;
                case 1:
                    return CheckState.Checked;
                default:
                    throw new Exception("Value for Checkbox: " + CheckState.Indeterminate);
            }
        }

        private int GetChecked(bool value)
        {
            switch (value)
            {
                case false:
                    return 0;
                case true:
                    return 1;
                default:
                    throw new Exception("Value for Checkbox out of range: " + value);
            }
        }

        private int GetLatchControl(int control)
        {
            switch (control)
            {
                case 0:
                    return (int)LatchControl.TransparentMode;
                case 1:
                    return (int)LatchControl.ComparaterMode;
                default:
                    throw new Exception("LatchControl out of range: " + control);
            }
        }

        private int GetAlertPolarity(int polarity)
        {
            switch (polarity)
            {
                case 0:
                    return (int)AlertPolarity.ActiveLow;
                case 1:
                    return (int)AlertPolarity.ActiveHigh;
                default:
                    throw new Exception("AlertPolarity out of range: " + polarity);
            }
        }

        private int GetExponentMask(int mask)
        {
            switch (mask)
            {
                case 0:
                    return (int)ExponentMask.Unmasked;
                case 1:
                    return (int)ExponentMask.Masked;
                default:
                    throw new Exception("ExponentMask out of range: " + mask);
            }
        }

        private int GetFaultCount(int faultCount)
        {
            switch (faultCount)
            {
                case 0:
                    return (int)FaultCount.FC1;
                case 1:
                    return (int)FaultCount.FC2;
                case 2:
                    return (int)FaultCount.FC3;
                case 3:
                    return (int)FaultCount.FC4;
                default:
                    throw new Exception("FaultCount out of range: " + faultCount);
            }
        }

        internal void GetManuID()
        {
            try
            {
                String slave = DEFAULT_SLAVE;
                string command = "S"+ slave + " 7E R02 P" ;
                string result = this.UsbI2C.SendReceiveCommand(command);
                this.manuID = "0x" + result + "TI";
            }
            catch
            {
                throw new Exception("Could not read Manufacturer ID");
            }
        }

          internal void SetDeviceID()
          {
              this.GetDeviceID();
              this.uiElements.LabelDeviceID.Text = this.deviceID;
          }
          internal void SetManuID()
          {
              this.GetManuID();
              this.uiElements.LabelManufactureID.Text = this.manuID;
          }


        internal void GetDeviceID()
        {
            try
            {
                String slave = DEFAULT_SLAVE;
                string command = "S" + slave + " 7F R02 P";
                string result = this.UsbI2C.SendReceiveCommand(command);
                this.deviceID ="0x" + result;
            }
            catch
            {
                throw new Exception("Could not read Device ID");
            }
        }

        internal string SendReceiveCommand(string command)
        {
           return this.UsbI2C.SendReceiveCommand(command);
        }


        public double getMaxLux()
        {
            return MAX_LUX;
        }

        public double getMinLux()
        {
            return MIN_LUX;
        }

        public int getMaxMantissa()
        {
            return MAX_MANTISSA;
        }

        public int getMinMantissa()
        {
            return MIN_MANTISSA;
        }

        public int getMaxExponent()
        {
            return MAX_EXPONENT;
        }

        public int getMinExponent()
        {
            return MIN_EXPONENT;
        }

        internal void reloadTextBoxes(string p)
        {
            switch (p)
            {
                case "lll":
                    this.GetMantissaAndExponent(p, Double.Parse(this.uiElements.TextBoxLowLimitLux.Text));
                    this.uiElements.TextBoxLowLimitExponent.Text = this.lowLimitExponent;
                    this.uiElements.TextBoxLowLimitMantissa.Text = this.lowLimitMantissa;
                    break;
                case "hll":
                    this.GetMantissaAndExponent(p, Double.Parse(this.uiElements.TextBoxHighLimitLux.Text));
                    this.uiElements.TextBoxHighLimitExponent.Text = this.highLimitExponent;
                    this.uiElements.TextBoxHighLimitMantissa.Text = this.highLimitMantissa;
                    break;
                case "lle":
                case "llm":
                    try
                    {
                        int mantissa = Int32.Parse(this.uiElements.TextBoxLowLimitMantissa.Text, NumberStyles.AllowHexSpecifier);
                        int exponent = Int32.Parse(this.uiElements.TextBoxLowLimitExponent.Text, NumberStyles.AllowHexSpecifier);
                        this.uiElements.TextBoxLowLimitLux.Text = this.GetLux(exponent, mantissa).ToString();
                    }
                    catch (Exception e)
                    {
                        throw new Exception("" + e);
                    }
                    break;
                case "hle":
                case "hlm":
                    try
                    {
                        int mantissa = Int32.Parse(this.uiElements.TextBoxHighLimitMantissa.Text, NumberStyles.AllowHexSpecifier);
                        int exponent = Int32.Parse(this.uiElements.TextBoxHighLimitExponent.Text, NumberStyles.AllowHexSpecifier);
                        this.uiElements.TextBoxHighLimitLux.Text = this.GetLux(exponent, mantissa).ToString();
                   }
                    catch (Exception e)
                    {
                        throw new Exception("" + e);
                    }
                    break;
                default:
                    break;
            }
        }

        private void GetMantissaAndExponent(String p, double lux)
        {
            uint luxInt = (uint)(lux * 100);
            uint exponent = 0;
            uint mantisse = 0;
            for (exponent = 0; exponent < 16; exponent++)
            {
                if (((1 << (byte)exponent) * 0x0fff) > luxInt)
                {
                    mantisse = (uint)(luxInt / (1 << (byte)exponent));
                    break;
                }
            }
            if (exponent > 11)
            {
                exponent = 11;
                mantisse = 0x0fff;
            }
            if (p.Equals("hll"))
            {
                this.highLimitExponent = (exponent & 0x0f).ToString("X1");

                if ((mantisse & 0x0fff) > 9)
                {
                    this.highLimitMantissa = (mantisse & 0x0fff).ToString("X2");
                }
                else
                {
                    this.highLimitMantissa = (mantisse & 0x0fff).ToString();
                }
            }
            else if(p.Equals("lll"))
            {
                this.lowLimitExponent = (exponent & 0x0f).ToString("X1");

                if ((mantisse & 0x0fff) > 9)
                {
                    this.lowLimitMantissa = (mantisse & 0x0fff).ToString("X2");
                }
                else
                {
                    this.lowLimitMantissa = (mantisse & 0x0fff).ToString();
                }

            }
        }
    }
}
