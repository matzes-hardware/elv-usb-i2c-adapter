﻿//-----------------------------------------------------------------------------
// <copyright file="Program.cs" company="eQ-3 Entwicklung GmbH">
//  Copyright (c) 2013 eQ-3 Entwicklung GmbH
// </copyright>
// <summary>
// Initialising main window.
// </summary>
//-----------------------------------------------------------------------------
namespace Eq3.misc.USBI2C
{
    using System;
    using System.Windows.Forms;

    /// <summary>
    /// Initializing main window.
    /// </summary>
    public static class Program
    {
        /// <summary>
        /// Initialising main window.
        /// </summary>
        [STAThread]
        public static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}
