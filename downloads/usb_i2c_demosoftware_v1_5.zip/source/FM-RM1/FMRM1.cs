//-----------------------------------------------------------------------------
// <copyright file="FMRM1.cs" company="eQ-3 Entwicklung GmbH">
//  Copyright (c) 2014 eQ-3 Entwicklung GmbH
// </copyright>
//-----------------------------------------------------------------------------

namespace Eq3.misc.USBI2C.FM_RM1
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using System.Windows.Forms;

    /// <summary>
    /// Template Class
    /// </summary>
    public class FMRM1
        : AbstractDevice
    {
        /// <summary>
        /// The address of the FM-RM1 on I2C
        /// </summary>
        private const byte FMRM1Address = 0xC6;

        /// <summary>
        /// Imported UI-Elements of FMRM1.
        /// </summary>
        private FMRM1.UiElements uiElements;

         /// <summary>
        /// Initializes a new instance of the FMRM1 class.
        /// </summary>
        /// <param name="usbI2C">I2C comport-device.</param>
        public FMRM1(UsbI2C usbI2C)
            : base(usbI2C)
        {
        }

        /// <summary>
        /// Imports the UI-Elements of the FMRM1.
        /// </summary>
        /// <param name="uiElements">UI-Elements of the FMRM1.</param>
        public void ImportUiElements(UiElements uiElements)
        {
            this.uiElements = uiElements;
        }

        /// <summary>
        /// Initializes the FM-RM1 device
        /// </summary>
        public void Initialize()
        {
            this.PowerUp();
            this.GetRevision();
            this.RDSConfig();
            this.SelectAntenna(0);

            this.Seek(true);

            if (this.uiElements.Volume.Value == 30)
            {
                this.SetVolume(30);
            }
            else
            {
                // this.SetVolume(30); will be called by the value changed of the ui element
                this.uiElements.Volume.Value = 30;
            }

            if (!this.uiElements.Mute.Checked)
            {
                this.Mute(false);
            }
            else
            {
                // this.Mute(false); will be called by the checked changed of the ui element
                this.uiElements.Mute.Checked = false;
            }
        }

        /// <summary>
        /// Power up the device
        /// </summary>
        public void PowerUp()
        {
            string[] commandList = new string[3];
            //Powerup
            commandList[0] = "S" + FMRM1.FMRM1Address.ToString("X2") + " 01 D0 05 P";
            //Disable Debug
            commandList[1] = "S" + FMRM1.FMRM1Address.ToString("X2") + " 12 00 FF 00 00 00 P";

            commandList[2] = "S" + FMRM1.FMRM1Address.ToString("X2") + " 12 00 11 00 00 01 P";

            foreach (string command in commandList)
            {
                this.uiElements.ListBoxOutput.Items.Add(command);
                this.uiElements.ListBoxOutput.TopIndex = this.uiElements.ListBoxOutput.Items.Count - 1;
                this.UsbI2C.SendCommand(command);
            }
        }

        /// <summary>
        /// Power down the device
        /// </summary>
        public void PowerDown()
        {
            string command = "S" + FMRM1.FMRM1Address.ToString("X2");
            command += " 11";
            command += " P";

            this.uiElements.ListBoxOutput.Items.Add(command);
            if (!this.UsbI2C.SendCommand(command))
            {
                //this.ShowError(4);
            }

            this.uiElements.VersionLabel.Text = string.Empty;
        }

        /// <summary>
        /// Get the revision
        /// </summary>
        /// <returns></returns>
        public void GetRevision()
        {
            string command = "S" + FMRM1.FMRM1Address.ToString("X2");

            command += " 10 R09 P";

            string result = this.UsbI2C.SendReceiveCommand(command);

            if (result != string.Empty)
            {
                this.uiElements.ListBoxInput.Items.Add(result);
                this.uiElements.ListBoxInput.TopIndex = this.uiElements.ListBoxInput.Items.Count - 1;
                if (result.StartsWith("Err") || result.StartsWith("R"))
                {
                    return;
                }

                try
                {
                    // Status auswerten
                    result = result.Replace(" ", string.Empty);
                    byte[] resultBytes = new byte[result.Length / 2];
                    for (int i = 0; i < result.Length; i += 2)
                    {
                        resultBytes[i / 2] = Convert.ToByte(result.Substring(i, 2), 16);
                    }

                    byte status = resultBytes[0];
                    byte partnumber = resultBytes[1];
                    byte rev_major = resultBytes[2];
                    byte rev_minor = resultBytes[3];
                    int patch = resultBytes[4] << 8 | resultBytes[5];
                    byte firmwareMajor = resultBytes[6];
                    byte firmwareMinor = resultBytes[7];
                    byte chip_rev = resultBytes[8];
                    this.uiElements.VersionLabel.Text = string.Format("Revision: {0}.{1}.{2} Firmware: {3}.{4}", rev_major, rev_minor, patch, firmwareMajor, firmwareMinor);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }

        /// <summary>
        /// Configures the RDS
        /// </summary>
        public void RDSConfig()
        {
            string[] commandList = new string[3];
            commandList[0] = "S" + FMRM1.FMRM1Address.ToString("X2") + " 12 00 15 00 00 01 P";
            commandList[1] = "S" + FMRM1.FMRM1Address.ToString("X2") + " 12 00 15 01 00 01 P";
            commandList[2] = "S" + FMRM1.FMRM1Address.ToString("X2") + " 12 00 15 02 FF 01 P";

            foreach (string command in commandList)
            {
                this.uiElements.ListBoxOutput.Items.Add(command);
                this.uiElements.ListBoxOutput.TopIndex = this.uiElements.ListBoxOutput.Items.Count - 1;
                this.UsbI2C.SendCommand(command);
            }
        }

        /// <summary>
        /// Select the antenna
        /// </summary>
        /// <param name="antenna">The number of the antenna</param>
        public void SelectAntenna(byte antenna)
        {
            string command = "S" + FMRM1.FMRM1Address.ToString("X2") + " 12 00 11 07 00";
            command += antenna.ToString("X2");
            command += " P";

            this.uiElements.ListBoxOutput.Items.Add(command);
            if (!this.UsbI2C.SendCommand(command))
            {
                //this.ShowError(4);
            }
        }

        /// <summary>
        /// Set the output volume
        /// </summary>
        /// <param name="volume">The volume value that should be set</param>
        public void SetVolume(short volume)
        {
            string command = "S" + FMRM1.FMRM1Address.ToString("X2");

            command += " 12 00 40 00 00 ";
            command += volume.ToString("X2");
            command += " P";

            this.uiElements.ListBoxOutput.Items.Add(command);
            if (!this.UsbI2C.SendCommand(command))
            {
                //this.ShowError(4);
            }
        }

        public void GetVolume()
        {
            string command = "S" + FMRM1.FMRM1Address.ToString("X2");

            command += " 13 00 40 00 R04 P";

            string result = this.UsbI2C.SendReceiveCommand(command);

            if (result != string.Empty)
            {                
                this.uiElements.ListBoxInput.Items.Add(result);
                this.uiElements.ListBoxInput.TopIndex = this.uiElements.ListBoxInput.Items.Count - 1;
                if (result.StartsWith("Err") || result.StartsWith("R"))
                {
                    return;
                }

                try
                {
                    // Status auswerten
                    result = result.Replace(" ", string.Empty);
                    byte[] resultBytes = new byte[result.Length / 2];
                    for (int i = 0; i < result.Length; i += 2)
                    {
                        resultBytes[i / 2] = Convert.ToByte(result.Substring(i, 2), 16);
                    }

                    byte status = resultBytes[0];
                    byte volume = resultBytes[3];
                    this.uiElements.Volume.Value = volume;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

        }

        /// <summary>
        /// Activates or deactivates the mute
        /// </summary>
        /// <param name="OnOff">True if the mute should be enabled, else false</param>
        public void Mute(bool OnOff)
        {
            //Set GPIO1 as Output
            string command = "S" + FMRM1.FMRM1Address.ToString("X2") + " 80 02 P";
            if (!this.UsbI2C.SendCommand(command))
            {
                //this.ShowError(4);
            }

            //Set GPIO1 State
            command = "S" + FMRM1.FMRM1Address.ToString("X2") + " 81 ";
            if (OnOff)
            {
                command += "02 P";
            }
            else
            {
                command += "00 P";
            }

            this.uiElements.ListBoxOutput.Items.Add(command);
            if (!this.UsbI2C.SendCommand(command))
            {
                //this.ShowError(4);
            }
        }

        /// <summary>
        /// Sets the channel or frequency of the FM-RM1
        /// </summary>
        /// <param name="channel">The channel or frequency</param>
        public void SetChannel(int channel)
        {
            string command = "S" + FMRM1.FMRM1Address.ToString("X2");

            command += " 20 00 ";
            command += ((channel >> 8) & 0xff).ToString("X2") + " ";
            command += (channel & 0xff).ToString("X2");
            command += " 00 P";

            this.uiElements.ListBoxOutput.Items.Add(command);
            if (!this.UsbI2C.SendCommand(command))
            {
                //this.ShowError(4);
            }

            this.uiElements.Frequency.Text = string.Format("{0} MHz", channel / 100.0);
        }

        /// <summary>
        /// Seeks for the next sender or the maximumm seek step
        /// </summary>
        /// <param name="direction">True if the direction is forward</param>
        public void Seek(bool direction)
        {
            string command = "S" + FMRM1.FMRM1Address.ToString("X2");

            command += " 21";

            if (direction)
            {
                command += " 0C";
            }
            else
            {
                command += " 04";
            }

            command += " P";
            this.uiElements.ListBoxOutput.Items.Add(command);
            if (!this.UsbI2C.SendCommand(command))
            {
                //this.ShowError(4);
            }
        }

        //FM_TUNE_STATUS
        public void TuneStatus()
        {
            string command = "S" + FMRM1.FMRM1Address.ToString("X2");

            command += " 22 03 R08 P";

            string result = this.UsbI2C.SendReceiveCommand(command);

            if (result != string.Empty)
            {
                this.uiElements.ListBoxInput.Items.Add(result);
                this.uiElements.ListBoxInput.TopIndex = this.uiElements.ListBoxInput.Items.Count - 1;
                if (result.StartsWith("Err") || result.StartsWith("R"))
                {
                    return;
                }

                try
                {
                    // Status auswerten
                    result = result.Replace(" ", string.Empty);
                    byte[] resultBytes = new byte[result.Length / 2];
                    for (int i = 0; i < result.Length; i += 2)
                    {
                        resultBytes[i / 2] = Convert.ToByte(result.Substring(i, 2), 16);
                    }

                    byte status = resultBytes[0];
                    EncodeStatus(status);
                    if ((status & 0x20) != 0)
                    {
                        //this.ShowError(4);
                    }

                    this.uiElements.Valid.Checked = Convert.ToBoolean(resultBytes[1] & 0x01);
                    this.uiElements.AFC.Checked = Convert.ToBoolean(resultBytes[1] & 0x02);
                    int channel = resultBytes[2] << 8 | resultBytes[3];
                    this.uiElements.FrequencyBar.Value = channel / 10;
                    this.uiElements.Frequency.Text = string.Format("{0} MHz", channel / 100.0);
                    this.uiElements.RSSI.Text = string.Format("{0} dB�V", resultBytes[4]);
                    this.uiElements.SNR.Text = string.Format("{0} dB", resultBytes[5]);
                    this.uiElements.Multipath.Text = string.Format("{0}", resultBytes[6]);
                    this.uiElements.AntennaCap.Text = string.Format("{0}", resultBytes[7]);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }

        private void EncodeStatus(byte status)
        {
            this.uiElements.STCINT.Checked = Convert.ToBoolean(status & 0x01);
            this.uiElements.RDS.Checked = Convert.ToBoolean(status & 0x04);
            this.uiElements.RSQINT.Checked = Convert.ToBoolean(status & 0x08);
            this.uiElements.Error.Checked = Convert.ToBoolean(status & 0x40);
            this.uiElements.CTS.Checked = Convert.ToBoolean(status & 0x80);
        }

        //FM_RSQ_STATUS
        public void RSQStatus()
        {
            string command = "S" + FMRM1.FMRM1Address.ToString("X2");

            command += " 23 01 R08 P";

            string result = this.UsbI2C.SendReceiveCommand(command);

            if (result != string.Empty)
            {                
                this.uiElements.ListBoxInput.Items.Add(result);
                this.uiElements.ListBoxInput.TopIndex = this.uiElements.ListBoxInput.Items.Count - 1;
                if (result.StartsWith("Err") || result.StartsWith("R"))
                {
                   return;
                }

                try
                {
                    // Status auswerten
                    result = result.Replace(" ", string.Empty);
                    byte[] resultBytes = new byte[result.Length / 2];
                    for (int i = 0; i < result.Length; i += 2)
                    {
                        resultBytes[i / 2] = Convert.ToByte(result.Substring(i, 2), 16);
                    }

                    byte status = resultBytes[0];
                    EncodeStatus(status);

                    this.uiElements.Valid.Checked = Convert.ToBoolean(resultBytes[2] & 0x01);
                    this.uiElements.AFC.Checked = Convert.ToBoolean(resultBytes[2] & 0x02);
                    this.uiElements.Softmute.Checked = Convert.ToBoolean(resultBytes[2] & 0x08);
                    this.uiElements.Pilot.Checked = Convert.ToBoolean(resultBytes[3] & 0x80);
                    this.uiElements.Stereoblend.Text = string.Format("{0} %", resultBytes[3] & 0x7F);
                    this.uiElements.RSSI.Text = string.Format("{0} dB�V", resultBytes[4]);
                    this.uiElements.SNR.Text = string.Format("{0} dB", resultBytes[5]);
                    this.uiElements.Multipath.Text = string.Format("{0}", resultBytes[6]);
                    this.uiElements.FreqOffset.Text = string.Format("{0} kHz", resultBytes[7]);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }

            }
        }

        /// <summary>
        /// UI-Elements of the MCP9801.
        /// </summary>
        public struct UiElements
        {
            /// <summary>
            /// Gets or sets output-command list.
            /// </summary>
            /// <value>Output-command list.</value>
            public ListBox ListBoxOutput { get; set; }

            /// <summary>
            /// Gets or sets input-command list.
            /// </summary>
            /// <value>Input-command list.</value>
            public ListBox ListBoxInput { get; set; }

            /// <summary>
            /// Gets or sets the label where the version should be displayed
            /// </summary>
            public Label VersionLabel { get; set; }

            /// <summary>
            /// Gets or sets the numberic up down where the volume is shown
            /// </summary>
            public NumericUpDown Volume { get; set; }

            /// <summary>
            /// Gets or sets the check box for the mute value
            /// </summary>
            public CheckBox Mute { get; set; }

            /// <summary>
            /// Gets or sets the label for the frequency value
            /// </summary>
            public Label Frequency { get; set; }

            /// <summary>
            /// Gets or sets the label for the frequency value
            /// </summary>
            public TrackBar FrequencyBar { get; set; }

            /// <summary>
            /// Gets or sets the check box for AFC value
            /// </summary>
            public CheckBox AFC { get; set; }

            /// <summary>
            /// Gets or sets the check box for valid value
            /// </summary>
            public CheckBox Valid { get; set; }

            /// <summary>
            /// Gets or sets the check box for pilot value
            /// </summary>
            public CheckBox Pilot { get; set; }

            /// <summary>
            /// Gets or sets the check box for softmute value
            /// </summary>
            public CheckBox Softmute { get; set; }

            /// <summary>
            /// Gets or sets the text box for RSSI value
            /// </summary>
            public TextBox RSSI { get; set; }

            /// <summary>
            /// Gets or sets the text box for SR value
            /// </summary>
            public TextBox SNR { get; set; }

            /// <summary>
            /// Gets or sets the text box for multipath value
            /// </summary>
            public TextBox Multipath { get; set; }

            /// <summary>
            /// Gets or sets the text box for antenna cap value
            /// </summary>
            public TextBox AntennaCap { get; set; }

            /// <summary>
            /// Gets or sets the text box for stereoblend value
            /// </summary>
            public TextBox Stereoblend { get; set; }

            /// <summary>
            /// Gets or sets the text box for frequency offset value
            /// </summary>
            public TextBox FreqOffset { get; set; }

            /// <summary>
            /// Gets or sets the check box for CTS value
            /// </summary>
            public CheckBox CTS { get; set; }

            /// <summary>
            /// Gets or sets the check box for error value
            /// </summary>
            public CheckBox Error { get; set; }

            /// <summary>
            /// Gets or sets the check box for RSQINT value
            /// </summary>
            public CheckBox RSQINT { get; set; }
            
            /// <summary>
            /// Gets or sets the check box for RDS value
            /// </summary>
            public CheckBox RDS { get; set; }

            /// <summary>
            /// Gets or sets the check box for STCINT value
            /// </summary>
            public CheckBox STCINT { get; set; }
        }
    }
}