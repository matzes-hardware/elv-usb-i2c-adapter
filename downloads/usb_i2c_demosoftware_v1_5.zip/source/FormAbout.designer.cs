﻿namespace Eq3.misc.USBI2C
{
    partial class FormAbout
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnOK = new System.Windows.Forms.Button();
            this.lbURLSupportDescription = new System.Windows.Forms.Label();
            this.lbURLSupport = new System.Windows.Forms.LinkLabel();
            this.lbProductVersion = new System.Windows.Forms.Label();
            this.lbProductName = new System.Windows.Forms.Label();
            this.picLogo = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // btnOK
            // 
            this.btnOK.BackColor = System.Drawing.SystemColors.Control;
            this.btnOK.Location = new System.Drawing.Point(206, 360);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(75, 23);
            this.btnOK.TabIndex = 0;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = false;
            this.btnOK.Click += new System.EventHandler(this.BtnOK_Click);
            // 
            // lbURLSupportDescription
            // 
            this.lbURLSupportDescription.AutoSize = true;
            this.lbURLSupportDescription.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbURLSupportDescription.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbURLSupportDescription.Location = new System.Drawing.Point(8, 282);
            this.lbURLSupportDescription.Name = "lbURLSupportDescription";
            this.lbURLSupportDescription.Size = new System.Drawing.Size(126, 15);
            this.lbURLSupportDescription.TabIndex = 7;
            this.lbURLSupportDescription.Text = "Produkt:";
            // 
            // lbURLSupport
            // 
            this.lbURLSupport.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbURLSupport.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbURLSupport.Location = new System.Drawing.Point(8, 307);
            this.lbURLSupport.Name = "lbURLSupport";
            this.lbURLSupport.Size = new System.Drawing.Size(467, 27);
            this.lbURLSupport.TabIndex = 8;
            this.lbURLSupport.TabStop = true;
            this.lbURLSupport.Text = "https://www.elv.de/usb-i-c-interface-usb-i2c-1.html";
            this.lbURLSupport.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LabelURLSupport_LinkClicked);
            // 
            // lbProductVersion
            // 
            this.lbProductVersion.AutoSize = true;
            this.lbProductVersion.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbProductVersion.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbProductVersion.Location = new System.Drawing.Point(8, 256);
            this.lbProductVersion.Name = "lbProductVersion";
            this.lbProductVersion.Size = new System.Drawing.Size(133, 15);
            this.lbProductVersion.TabIndex = 6;
            this.lbProductVersion.Text = "Version 1.0 (2007-07-23)";
            // 
            // lbProductName
            // 
            this.lbProductName.Font = new System.Drawing.Font("Segoe UI", 16.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbProductName.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbProductName.Location = new System.Drawing.Point(6, 143);
            this.lbProductName.Name = "lbProductName";
            this.lbProductName.Size = new System.Drawing.Size(467, 72);
            this.lbProductName.TabIndex = 5;
            this.lbProductName.Text = "Produktname";
            this.lbProductName.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // picLogo
            // 
            this.picLogo.Image = global::Eq3.misc.USBI2C.Properties.Resources.ELVLogo;
            this.picLogo.Location = new System.Drawing.Point(6, 12);
            this.picLogo.Name = "picLogo";
            this.picLogo.Size = new System.Drawing.Size(467, 128);
            this.picLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picLogo.TabIndex = 9;
            this.picLogo.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(8, 230);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 15);
            this.label1.TabIndex = 10;
            this.label1.Text = "ELV Elektronik AG";
            // 
            // FormAbout
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(485, 395);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.picLogo);
            this.Controls.Add(this.lbURLSupportDescription);
            this.Controls.Add(this.lbURLSupport);
            this.Controls.Add(this.lbProductVersion);
            this.Controls.Add(this.lbProductName);
            this.Controls.Add(this.btnOK);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormAbout";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Info über ELV iSMT-Testtool";
            this.Load += new System.EventHandler(this.FormAbout_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Label lbURLSupportDescription;
        private System.Windows.Forms.LinkLabel lbURLSupport;
        private System.Windows.Forms.Label lbProductVersion;
        private System.Windows.Forms.Label lbProductName;
        private System.Windows.Forms.PictureBox picLogo;
        private System.Windows.Forms.Label label1;
    }
}